from django.contrib import admin

from board.models import Fboard

# Register your models here.

admin.site.register(Fboard)